package com.example.exercicio2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etValor1, etValor2;
    private Button btnSoma, btnSubtracao, btnMultiplicacao, btnDivisao;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etValor1 = findViewById(R.id.etValor1);
        etValor2 = findViewById(R.id.etValor2);
        btnSoma = findViewById(R.id.btnSoma);
        btnSubtracao = findViewById(R.id.btnSubtracao);
        btnMultiplicacao = findViewById(R.id.btnMultiplicacao);
        btnDivisao = findViewById(R.id.btnDivisao);
        tvResultado = findViewById(R.id.tvResultado);


        btnSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarOperacao("+");
            }
        });


        btnSubtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarOperacao("-");
            }
        });


        btnMultiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarOperacao("*");
            }
        });


        btnDivisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                realizarOperacao("/");
            }
        });
    }


    @SuppressLint("SetTextI18n")
    private void realizarOperacao(String operador) {
        try {

            double valor1 = Double.parseDouble(etValor1.getText().toString());
            double valor2 = Double.parseDouble(etValor2.getText().toString());
            double resultado = 0;


            switch (operador) {
                case "+":
                    resultado = valor1 + valor2;
                    break;
                case "-":
                    resultado = valor1 - valor2;
                    break;
                case "*":
                    resultado = valor1 * valor2;
                    break;
                case "/":
                    if (valor2 != 0) {
                        resultado = valor1 / valor2;
                    } else {
                        tvResultado.setText("Erro: Não se deve dividir por 0");
                        return;
                    }
                    break;
            }


            tvResultado.setText("Resultado: " + resultado);

        } catch (NumberFormatException e) {
            tvResultado.setText("Erro: Digite valores válidos");
        }
    }
}
