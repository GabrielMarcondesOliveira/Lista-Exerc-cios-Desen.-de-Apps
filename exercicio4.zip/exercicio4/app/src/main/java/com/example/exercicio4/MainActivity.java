package com.example.exercicio4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtName;
    private Button btnGenerate;
    private LinearLayout checkboxContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        btnGenerate = findViewById(R.id.btnGenerate);
        checkboxContainer = findViewById(R.id.checkboxContainer);

        btnGenerate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edtName.getText().toString().trim();
                checkboxContainer.removeAllViews();
                for (char letter : name.toCharArray()) {
                    CheckBox checkBox = new CheckBox(MainActivity.this);
                    checkBox.setText(String.valueOf(letter));
                    checkboxContainer.addView(checkBox);
                }
            }
        });
    }
}
