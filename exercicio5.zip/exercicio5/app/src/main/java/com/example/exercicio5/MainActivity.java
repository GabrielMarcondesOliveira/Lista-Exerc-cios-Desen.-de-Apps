package com.example.exercicio5;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private CheckBox chkNotificacoes, chkModoEscuro, chkLembrarLogin;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkNotificacoes = findViewById(R.id.chkNotificacoes);
        chkModoEscuro = findViewById(R.id.chkModoEscuro);
        chkLembrarLogin = findViewById(R.id.chkLembrarLogin);
        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder preferencias = new StringBuilder();

                if (chkNotificacoes.isChecked()) preferencias.append("Receber notificações\n");
                if (chkModoEscuro.isChecked()) preferencias.append("Modo escuro\n");
                if (chkLembrarLogin.isChecked()) preferencias.append("Lembrar login\n");

                String resultado = preferencias.length() > 0 ? preferencias.toString() : "Nenhuma preferência foi escolhida";
                Toast.makeText(MainActivity.this, resultado, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
