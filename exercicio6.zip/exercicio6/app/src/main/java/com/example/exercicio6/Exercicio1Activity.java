package com.example.exercicio6;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Exercicio1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio1);

        EditText nameInput = findViewById(R.id.nameInput);
        EditText ageInput = findViewById(R.id.ageInput);
        Button checkButton = findViewById(R.id.checkButton);
        TextView resultText = findViewById(R.id.resultText);

        checkButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String name = nameInput.getText().toString();
                String ageString = ageInput.getText().toString();

                if (!name.isEmpty() && !ageString.isEmpty()) {
                    try {
                        int age = Integer.parseInt(ageString);
                        if (age >= 18) {
                            resultText.setText(name + " é maior de idade!");
                        } else {
                            resultText.setText(name + " não é maior de idade...");
                        }
                    } catch (NumberFormatException e) {
                        resultText.setText("Por favor, insira um número inteiro.");
                    }
                } else {
                    resultText.setText("Preencha os campos corretamente.");
                }
            }
        });
    }
}
